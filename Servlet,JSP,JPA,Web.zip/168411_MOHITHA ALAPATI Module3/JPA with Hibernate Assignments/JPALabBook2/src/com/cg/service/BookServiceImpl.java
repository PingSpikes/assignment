package com.cg.service;

import java.util.List;

import com.cg.dao.BookDaoImpl;
import com.cg.dao.IBookDao;

import com.cg.entity.Book;

public class BookServiceImpl implements IBookService {
	IBookDao its=null;


	@Override
	public Book getBookById(int id) {
		its=new BookDaoImpl();
		return its.getBookById(id);
	}

	@Override
	public List<Book> getBookByTitle(String title) {
		its=new BookDaoImpl();
		return its.getBookByTitle(title);
	}

	@Override
	public Long getBookCount() {
		its=new BookDaoImpl();
		return its.getBookCount();
		
	}

	@Override
	public List<Book> getAuthorBook(String author) {
		its=new BookDaoImpl();
		return its.getAuthorBook(author);
	}

	@Override
	public List<Book> getAllBooks() {
		its=new BookDaoImpl();
		return its.getAllBooks();
	}

	@Override
	public List<Book> getBookInPriceRange(double low, double high) {
		its=new BookDaoImpl();
		return its.getBookInPriceRange(low,high);
	}

}
