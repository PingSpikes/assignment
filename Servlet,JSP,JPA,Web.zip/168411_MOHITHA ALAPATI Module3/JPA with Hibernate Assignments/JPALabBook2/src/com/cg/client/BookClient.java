package com.cg.client;

import com.cg.entity.Book;
import com.cg.service.BookServiceImpl;
import com.cg.service.IBookService;

public class BookClient {
	static IBookService bsi=null;
	public static void main(String[] args) {
		 bsi=new BookServiceImpl();
		System.out.println("Listing of total number of books");
		System.out.println("Totalbooks: "+bsi.getBookCount());
		System.out.println("Listing book with id 105");
		System.out.println("Book with Id 105:"+bsi.getBookById(105));
		System.out.println("Listing all books");
		for(Book book:bsi.getAllBooks())
		{
			System.out.println(book);
		
		}
		System.out.println("Listing book on Android");
		for(Book book:bsi.getBookByTitle("Android"))
		{
			System.out.println(book);
		}
		System.out.println("List of books within the range");
		for(Book book:bsi.getBookInPriceRange(100,500))
		{
			System.out.println(book);
		}
		System.out.println("Listing book on Herbert Schildt");
		for(Book book:bsi.getAuthorBook("Herbert Schildt"))
		{
			System.out.println(book);
		}
	}

}
