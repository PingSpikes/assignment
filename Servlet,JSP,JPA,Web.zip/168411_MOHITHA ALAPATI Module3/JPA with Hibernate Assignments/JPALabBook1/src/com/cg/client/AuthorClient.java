package com.cg.client;



import com.cg.entity.Author;
import com.cg.service.IAuthorService;
import com.cg.service.AuthorServiceImpl;

public class AuthorClient {
	public static void main(String[] args) {
		Author a=new Author();
		IAuthorService itServ=new AuthorServiceImpl();
		a.setAuthorId(168411);
		a.setFirstName("Mohitha");
		a.setMiddleName("Nageswar");
		a.setLastName("Alapati");
		a.setPhoneno("8985993419");
		
	itServ.addAuthor(a);
		
	
		a=itServ.findAuthorById(168411);
		System.out.println("AuthorID:"+a.getAuthorId());
		System.out.println("FirstName:"+a.getFirstName());
		System.out.println("MiddleName:"+a.getMiddleName());
		System.out.println("LastName:"+a.getLastName());
		System.out.println("PhoneNumber:"+a.getPhoneno());
		a.setFirstName("Devil");
		itServ.updateAuthor(a);
		
		itServ.removeAuthor(a);
		System.out.println("End of the program");
	}

}
