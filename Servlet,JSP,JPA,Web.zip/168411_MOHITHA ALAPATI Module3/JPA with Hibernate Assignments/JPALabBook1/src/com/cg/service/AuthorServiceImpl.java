package com.cg.service;

import com.cg.dao.AuthorDaoImpl;
import com.cg.dao.IAuthorDao;
import com.cg.entity.Author;

public class AuthorServiceImpl implements IAuthorService{
	IAuthorDao its=null;

	@Override
	public void addAuthor(Author author) {
		its=new AuthorDaoImpl();
		its.beginTransaction();
		its.addAuthor(author);
		its.commitTransaction();
		
	}

	@Override
	public void updateAuthor(Author author) {
		its=new AuthorDaoImpl();
		its.beginTransaction();
		its.updateAuthor(author);
		its.commitTransaction();
		
	}

	@Override
	public void removeAuthor(Author author) {
		its=new AuthorDaoImpl();
		its.beginTransaction();
		its.removeAuthor(author);
		its.commitTransaction();
		
	}

	@Override
	public Author findAuthorById(int id) {
		its=new AuthorDaoImpl();
		return its.findAuthorById(id);
		
	}

}
