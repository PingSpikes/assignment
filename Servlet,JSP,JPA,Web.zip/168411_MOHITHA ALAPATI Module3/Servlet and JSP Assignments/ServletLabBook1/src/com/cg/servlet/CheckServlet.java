package com.cg.servlet;



import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/check.do")
public class CheckServlet extends HttpServlet {

	public CheckServlet() {
		super();
		// TODO Auto-generated constructor stub
	}
	PrintWriter out =null;
   @Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
	   out=resp.getWriter();
	String un="Mohitha";
	String pwd="123";
	   String username=req.getParameter("username");
	   String password=req.getParameter("password");
	 
	   if(un.equals(username)&&pwd.equals(password)){
		   //out.println("<html><head><title></title></head>");
			//out.println("<body>");
		    out.println("<a href=check.do?name=homeapplicances&id=904><img src= download.jpg></a>");
		    out.println("<a href=check.do?name=wetgrinder&id=204><img src= download1.jpg></a>");
		    out.println("<a href=check.do?name=combo&id=123><img src= download2.jpg></a>");
		   
		   // out.println("</body></html>");
	   }
	   else if(username==null&&password==null){
		  
		   String name=req.getParameter("name");
		   out.println(name+" is the name of the product");
		   String id=req.getParameter("id");
		   out.println(id+" is the id of the item");
		  
		   
	   }
	   
	   else
	  
		   out.println("enter valid information");
	   
}
   @Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
	doGet(req, resp);
}
}

