package com.cg.validation;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.validation.LoginBean;


@WebServlet("/Controller")
public class Controller  extends HttpServlet {
	private static final long serialVersionUID = 1L;

      public Controller () {
      
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LoginBean bean=new LoginBean();
		bean=(LoginBean)request.getAttribute("bean");
		String username=bean.getUsername();
		String password=bean.getPassword();
		System.out.println("In Controller doPost");
		System.out.println(username);
		System.out.println(password);
		RequestDispatcher rd=null;
		
	
		if(username.equals("cg")&&password.equals("1234")) {
			System.out.println("In Controller if");
			request.setAttribute("uName", username);
			rd=request.getRequestDispatcher("success.jsp");
		}
		else
		{
			System.out.println("login failed");
		}
		
		rd.include(request, response);
     
	
        
        
	}


}
