package com.cg.product.service;

import java.util.List;

import com.cg.product.bean.Product;
import com.cg.product.dao.IProductDAO;
import com.cg.product.dao.ProductDAOImpl;


public class ProductService implements IProductService {
	
		IProductDAO dao;

		public ProductService() {
			dao = new ProductDAOImpl();
		}

		/**
		 * Fetching all details of countries
		 * 
		 * @return List<Country>
		 */
		public List<Product> getAllProducts() {
			return dao.getAllProducts();
		}

		/**
		 * Fetching single product details
		 * 
		 * @param id
		 * @return product
		 */
		

		/**
		 * Creating a new Country
		 * 
		 * @param country
		 * @return Country
		 */
		public Product addProduct(Product product) {
			return dao.addProduct(product);
		}

		@Override
		public Product getProduct(int id) {
			// TODO Auto-generated method stub
			return dao.getProduct(id);
		}

		

}
