package com.cg.product.dao;

import java.util.List;

import com.cg.product.bean.Product;



public interface IProductDAO
{
	public List<Product> getAllProducts();
	public Product getProduct(Product product);
	public Product addProduct(Product product);
//	public Product retriveProduct(String product);
	
}
