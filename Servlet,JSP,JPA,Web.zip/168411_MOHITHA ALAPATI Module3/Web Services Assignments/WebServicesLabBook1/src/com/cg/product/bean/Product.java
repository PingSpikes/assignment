package com.cg.product.bean;

import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
public class Product
{
	private int productId;
	private String productName;
	private long productPrice;
	public Product() 
	{
	}
	public Product(int productId, String productName, long productPrice) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
	}
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public long getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(long productPrice) {
		this.productPrice = productPrice;
	}
}
