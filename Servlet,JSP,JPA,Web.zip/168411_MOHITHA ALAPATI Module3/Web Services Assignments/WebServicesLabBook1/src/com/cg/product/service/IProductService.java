package com.cg.product.service;

import java.util.List;

import com.cg.product.bean.Product;


public interface IProductService 
{
	public List<Product> getAllProducts();
	public Product addProduct(Product product);
	

Product getProduct(String product);
Product getProduct(Product product);
	
}
