package com.cg.product.staticdb;

import java.util.HashMap;
import com.cg.product.bean.Product;
public class ProductDB {

	 static  HashMap<Integer, Product> productIdMap=getProductIdMap();
	
	
		static {
			if (productIdMap == null) {
				productIdMap  = new HashMap<Integer, Product>();
				Product mobileProduct = new Product(1, "mobile", 10000);
				Product electronicProduct = new Product(4, "electronic", 20000);
				Product laptopsProduct= new Product(3, "laptops", 8000);
				Product desktopProduct = new Product(2, "desktop", 7000);

				productIdMap .put(1, mobileProduct);
				productIdMap .put(4, electronicProduct);
				productIdMap .put(3, laptopsProduct);
				productIdMap .put(2, desktopProduct);
			}
			else
			{
				
				 System.out.println("error occurred");

			
			}
		}
		
		/**
		 * This is a getter method of HashMap
		 * @return HashMap<Integer, product>
		 */
		
		public static  HashMap<Integer, Product> getProductIdMap() {

			
				if (productIdMap == null) {
					productIdMap  = new HashMap<Integer, Product>();
					Product mobileProduct = new Product(1, "mobile", 10000);
					Product electronicProduct = new Product(4, "electronic", 20000);
					Product laptopsProduct= new Product(3, "laptops", 8000);
					Product desktopProduct = new Product(2, "desktop", 7000);

					productIdMap .put(1, mobileProduct);
					productIdMap .put(4, electronicProduct);
					productIdMap .put(3, laptopsProduct);
					productIdMap .put(2, desktopProduct);
				}
				else
				{
					
					 System.out.println("error occurred");

				
				}
			
			return productIdMap;
		}
	}
