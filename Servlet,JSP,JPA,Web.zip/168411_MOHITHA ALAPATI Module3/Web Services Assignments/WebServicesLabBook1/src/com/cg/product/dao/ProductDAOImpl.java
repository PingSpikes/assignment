package com.cg.product.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.product.bean.Product;
import com.cg.product.staticdb.ProductDB;



public class ProductDAOImpl implements IProductDAO {
		static HashMap<Integer, Product> productIdMap = ProductDB.getProductIdMap();

		/**
		 * Fetching all details of countries
		 * 
		 * @return List<Country>
		 */
		public List<Product> getAllProducts() {
			List<Product> countries = new ArrayList<Product>(productIdMap.values());
			return countries;
		}

		/**
		 * Fetching single country details
		 * 
		 * @param id
		 * @return Country
		 */
		

		/**
		 * Creating a new Country
		 * 
		 * @param country
		 * @return Country
		 */
		public Product addProduct(Product product) {
			productIdMap.put(product.getProductId(), product);
			return product;
		}

		/**
		 * Updating an existing country
		 * 
		 * @param country
		 * @return Country
		 */
		public Product updateProduct(Product product) {
			if (product.getProductId() <= 0)
				return null;
			productIdMap.put(product.getProductId(), product);
			return product;

		}

		public Product getProduct(String name) {
			Product product = productIdMap.get("name");
			return product;
		}

		@Override
		public Product getProduct(Product product) {
			// TODO Auto-generated method stub
			return null;
		}

	
		
}