package com.cg.product.controller;



import java.util.List;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


import com.cg.product.bean.Product;
import com.cg.product.service.IProductService;
import com.cg.product.service.ProductService;


@Path("/product")
public class ProductController {
IProductService productService;

		public ProductController() {
			productService = new ProductService();
		}

		/**
		 * Method to list all country details, supporting HTTP GET method and
		 * produces Media type of JSON
		 * 
		 * @return List<product>
		 */
		@GET
		@Produces(MediaType.APPLICATION_XML)
		public List<Product> getProducts() {
			List<Product> listOfProducts = productService.getAllProducts();
			return listOfProducts;
		}

		/**
		 * Method to print specific country details, supporting HTTP GET method and
		 * produces Media type of JSON
		 * 
		 * @PathParam is used to extract parameter from URL
		 * @return product
		 */
		
		
		@POST
		@Produces(MediaType.APPLICATION_XML)
		public Product addProduct(@FormParam("txtId") int txtId,
				@FormParam("txtName") String txtName,
				@FormParam("txtPrice") long txtPrice) {
			Product product = new Product();
			product.setProductId(txtId);
			product.setProductName(txtName);
			product.setProductPrice(txtPrice);
			return productService.addProduct(product);
			
		}
		
		@GET
		@Path("/{id}")
		@Produces(MediaType.APPLICATION_XML)
		public Product getProductById(@PathParam("id") int id) {
			return productService.getProduct(id);
		}

	
}
		

	
